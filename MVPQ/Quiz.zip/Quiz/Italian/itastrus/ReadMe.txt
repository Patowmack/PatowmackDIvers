This archive contains a selection of vocabulary files
intended for native speakers of English. The files are
in Unicode Text and Rich Text (RTF) formats.

For educational use only. Not to be distributed without
this file (ReadMe.txt).

Copyright (C) 2006 Andrew Quilley. All rights reserved.

http://www.vocab.co.uk
andy@vocab.co.uk
