<?php header('Content-Type: text/html; charset=UTF-8');?>
<?php session_start(); ?>
<!DOCTYPE html>

<HTML>

<HEAD>

<LINK REL="stylesheet" TYPE="text/css" HREF="../images/quiz.css" /> 
<link rel="icon" 
      type="image/png" 
      href="/images/favicon.ico">
</HEAD>

<BODY onLoad = "document.question.ans.focus()" >
<DIV ID="top"></DIV>
<?php printf("<H2>Eric's Bahasa/Dutch/French/Italian/Spanish Language Quiz</H2>"); ?>
<DIV ID="container">
   
<?php
   printf("<a href=/Quiz/quiz.php?language=Bahasa>Bahasa</a><BR>");
   printf("<a href=/Quiz/quiz.php?language=Dutch>Dutch</a><BR>");
   printf("<a href=/Quiz/quiz.php?language=French>French</a><BR>");
   printf("<a href=/Quiz/quiz.php?language=Italian>Italian</a><BR>");
   printf("<a href=/Quiz/quiz.php?language=Spanish>Spanish</a><BR>");

   $_POST['ans'] = "";
   $_SESSION['group'] = "";
   $_SESSION['xOther'] = "";
   $_SESSION['english'] = "";
   $_SESSION['ex_corrects'] = "";
   $_SESSION['ex_attempts'] = "";
   $_SESSION['today_corrects'] = "";
   $_SESSION['today_attempts'] = "";
   $_SESSION['words'] = "";
   $_SESSION['ids'] ="";
   $_SESSION['id'] ="";
   $_SESSION['ex'] = "";
   $_SESSION['ans_previous'] = "";
   $_SESSION['firstInGroup'] = "";
   $_SESSION['firstInSubGroup'] = "";
   $_SESSION['started'] = "";
   $_SESSION['language'] = "";
   

?>
</DIV>

</BODY>
</HTML> 

