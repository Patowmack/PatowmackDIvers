loadbulkDutch.pl %1 %2

